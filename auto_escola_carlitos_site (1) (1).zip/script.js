const menuBtn = document.querySelector(".menu-btn");
const menu = document.querySelector(".menu");

if (menuBtn && menu) {
  menuBtn.addEventListener("click", () => {
    menu.classList.toggle("open");
  });

  document.querySelectorAll(".menu a").forEach(link => {
    link.addEventListener("click", () => menu.classList.remove("open"));
  });
}

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener("click", function (e) {
    const target = document.querySelector(this.getAttribute("href"));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  });
});

const form = document.getElementById("leadForm");
if (form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const nome = document.getElementById("nome").value.trim();
    const interesse = document.getElementById("interesse").value;
    const mensagem = document.getElementById("mensagem").value.trim();

    const texto = `Olá! Meu nome é ${nome}. Vim pelo site da Auto Escola Carlitos e tenho interesse em: ${interesse}. ${mensagem}`;
    const url = `https://wa.me/5519988050864?text=${encodeURIComponent(texto)}`;

    window.open(url, "_blank", "noopener");
  });
}

document.getElementById("year").textContent = new Date().getFullYear();
